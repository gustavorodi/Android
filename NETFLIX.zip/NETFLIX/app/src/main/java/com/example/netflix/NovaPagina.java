package com.example.netflix;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class NovaPagina extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nova_pagina);
    }
}
